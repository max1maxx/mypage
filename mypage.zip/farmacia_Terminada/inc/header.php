<?php
if(!isset($_SESSION)){
	session_start();
}
  require 'based/database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>

<!DOCTYPE html>
<head>
  <title> FÁRMACOS JMG </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">

  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet" href="css/magnific-popup.css">
  <link rel="stylesheet" href="css/jquery-ui.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  
  <link rel="stylesheet" href="css/aos.css">

  <link rel="stylesheet" href="css/style.css">


    <style type="text/css">
   
        body,td,th {
	        color: #000000;
        }
    </style>
    
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head>
</head>
<body>
  <div class="site-wrap">
    <div class="site-navbar py-2">


      <div class="container">
        <div class="d-flex align-items-center justify-content-between">
          <div class="logo">
            <div class="site-logo">
            <img src ="images/3.jpeg" width="100" height="100"><a href="index.php" class="js-logo-clone"><strong class="text-primary">FÁRMACOS JMG <br>¡Te cuida! </strong> </a>
            </div>
          </div>
          <div class="main-nav d-none d-lg-block">
            <nav class="site-navigation text-right text-md-center" role="navigation">
              <ul class="site-menu js-clone-nav d-none d-lg-block">
                <li <?php if ($pagina== "inicio") {echo "class='active'";}?>><a href="index.php"><h5>Inicio</h5></a></li>
                <li <?php if ($pagina== "Tienda") {echo "class='active'";}?>><a href="shop.php"><h5>Tienda</h5></a></li>
                <li class="has-children">
                  <a href="#"><h5>Categorías</h5></a>
                  <ul class="dropdown">
                    <li><a href="pdalergias.php"><h5> Alergía y antimareo </h5></a></li>
                    <li class="has-children">
                    <li><a href="pddolores.php"><h5>Dolores y articulaciones </h5></a></li>
                    <li><a href="pdgripe.php"><h5> Gripe y resfriado </h5></a></li>
                    <li><a href="vitamins.php"><h5>Vitaminas y suplementos</h5></a></li>
                  </ul>
                </li>
                <li <?php if ($pagina== "Ayuda") {echo "class='active'";}?>><a href="about.php"><h5>Ayuda</h5></a></li>
                <li <?php if ($pagina== "Contactarse") {echo "class='active'";}?>><a href="contact.php"><h5>Contactos</h5></a></li>
              </ul>
            </nav>
          </div>
          
          <div class="icons">
            <p><center><a href="mostrarCarrito.php" class="icons-btn d-inline-block bag" >
			<h1> </h1>
             <img src="images/carrito.png" WIDTH=30 HEIGHT=30>
              <span class="number">
                <?php
			            echo(empty($_SESSION['CARRITO']))?0:count($_SESSION['CARRITO']);
                ?>
            </a></center></p>

            <?php if(!empty($user)): ?>
            <br><center style="color: #75b239">Bienvenido</center>
            <?= $user['email']; ?></br>
            <center><h5><a href="based/logout.php"> <input type=button value="Cerrar sesión" name="boton"
                 style="BORDER: rgb(128,128,128) 1px dashed; FONT-SIZE: 11pt; FONT-FAMILY: Nunito;
                 BACKGROUND-COLOR: rgb(117,178,57); color: #E9E9E9  "></a></h5></center> 
            <?php else: ?>
            <a href="based/login.php"><h><input type=button value="Iniciar sesión" name="boton"
                 style="BORDER: rgb(128,128,128) 1px dashed; FONT-SIZE: 11pt; FONT-FAMILY: Nunito;
                 BACKGROUND-COLOR: rgb(117,178,57); color: #E9E9E9 "></h></a>
            <a href="based/signup.php"><input type=button value="Registrarse   " name="boton"
                 style="BORDER: rgb(128,128,128) 1px dashed; FONT-SIZE: 11pt; FONT-FAMILY: Nunito;
                 BACKGROUND-COLOR: rgb(117,178,57); color: #E9E9E9 "></a> 
            <?php endif; ?>
            <a href="#" class="site-menu-toggle js-menu-toggle ml-3 d-inline-block d-lg-none"><span
                class="icon-menu"></span>
            </a>
          </div>
        </div>
      </div>
    </div>