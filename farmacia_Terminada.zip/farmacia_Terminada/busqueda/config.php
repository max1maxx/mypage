<?php
function Conectar(){
$conexion = null;
$host = "localhost"; 	//TU HOST//
$dbuser = "root";	 	//TU USUARIO DEL HOST//
$dbpwd = "";	//TU CONTRASE�A//
$db = "farmacia";		//TU BASE DE DATOS//

try{
    $conexion = new PDO('mysql:host='.$host.';dbname='.$db, $dbuser, $dbpwd);
}
catch(PDOException $e){
    echo "<p> No se puede conectar an la base de datos</p>";
    exit;
}
return $conexion;
}
?>