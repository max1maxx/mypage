<?php

  require 'database.php';

  $message = '';

  if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $sql = "INSERT INTO users (email, password) VALUES (:email, :password)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt->bindParam(':password', $password);

    /*if ($stmt->execute()) {
      //$message = 'Nuevo usuario creado con éxito, inicie sesión';
      echo "<script>
                alert('Nuevo usuario creado con éxito, inicie sesión');
                window.location= 'login.php'
            </script>";
    } else {
      //$message = 'Lo sentimos, debe haber un problema al crear su cuenta.';
      echo "<script>
      alert('Lo sentimos, debe haber un problema al crear su cuenta.');
      window.location= 'login.php'
      </script>";
    }
    */

    if ($stmt->execute()) {
      ?> 
      <h3 class="ok">¡Nuevo usuario creado con éxito, inicie sesión!</h3>
         <?php
    } else {
      ?> 
      <h3 class="bad">¡Ups ha ocurrido un error!</h3>
         <?php
    }
  }   else {
      ?> 
      <h3 class="bad">¡Por favor complete los campos!</h3>
         <?php
  }
  
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Regístrate</title>
    <script>
      function comprobarClave(){
        password = document.f1.password.value
        confirm_password = document.f1.confirm_password.value
        if (password == confirm_password)
          execute();
        else
          alert("Las dos claves no coinciden, intente de nuevo")
          window.location= 'signup.php'       
      }
    </script>

    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  </head>
  <body>

    <?php if(!empty($message)): ?>
      <p> <?= $message ?></p>
    <?php endif; ?>
    <form name="f1" action="signup.php" method="POST">
    <button type="button" class="btn btn-default btn-sm">
    <a href="../index.php" ><span class="glyphicon glyphicon-home"></span> Volver a inicio
    </button></a>
    <center><h1>Regístrate</h1></center>
    <center><span>o <a href="login.php">Inicia sesión</a></span></center>
	  <center><input name="email" type="text" placeholder="Ingresa un correo electrónico" style='width:500px; height:40px'></center>
        <center><input name="password" type="password" placeholder="Ingresa una contraseña" style='width:500px; height:40px'></center>
        <center><input name="confirm_password" type="password" placeholder="Confirmar contraseña" style='width:500px; height:40px'></center>
      <center><h3><input type="submit" value="Registrar" onClick="comprobarClave()"></h3></center>
    </form>

  </body>
</html>