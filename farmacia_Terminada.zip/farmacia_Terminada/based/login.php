<?php

  session_start();

  if (isset($_SESSION['user_id'])) {
    header('Location: /farmacia_Casiterminada');
  }
  require 'database.php';

  if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE email = :email');
    $records->bindParam(':email', $_POST['email']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $message = '';

    if (count($results) > 0 && password_verify($_POST['password'], $results['password'])) {
      $_SESSION['user_id'] = $results['id'];
      header("Location: /farmacia_Casiterminada");
    } else {
      //$message = 'Lo siento, esas credenciales no coinciden';
      echo "<script>
      alert('Lo siento, esas credenciales no coinciden, intente de nuevo');
      window.location= 'login.php'
      </script>";
    }
  }

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Iniciar sesión</title>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">

    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  </head>
  
  <body>
    
    <?php if(!empty($message)): ?>
    <p> <?= $message ?></p>
    <?php endif; ?>
      
    <form action="login.php" method="post">
    <button type="button" class="btn btn-default btn-sm">
    <a href="../index.php" ><span class="glyphicon glyphicon-home"></span> Volver a inicio
    </button></a>
    
    <center><h1>Iniciar sesión</h1></center>
   <center> <span>o <a href="signup.php">Regístrate</a></span></center>
     <center> <input name="email" type="text" placeholder="Introduce tu correo electrónico" style='width:500px; height:40px'></center>
      <center><input name="password" type="password" placeholder="Ingresa tu contraseña" style='width:500px; height:40px'></center>
      <center><h3><input type="submit" value="Entrar"></h3></center>
    </form>
  </body>
</html>
