<footer class="site-footer bg-light">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-lg-4 mb-4 mb-lg-0">
                <div class="block-7">
                    <h3>Sobre  <strong class="text-primary">FÁRMACOS JMG</strong></h3>
                    <p  style="text-align: justify;">Somos un grupo de personas que trabajan con profesionales en farmacia para una correcta distribucción de los productos.</p>
                </div>
            </div>

            <div class="col-lg-3 mx-auto mb-5 mb-lg-0">
                <h3>Síguenos en</h3>
                <ul class="list-unstyled">
                    <li> <img src ="images/1.png" width="50" height="50"> <a href="https://www.facebook.com/?stype=lo&jlou=AfdRSM8YpOKbo-mc8cj9tvYQQJiFU25pPfb_FpxXq3LWxoN_kNLNUhVwMdPJfBQIZtk_TaEtGxXJNgx3y0fclsdgoUeReOe19ibGUC0dbb3JTw&smuh=5739&lh=Ac_9DFwel-FrxVlU"> farmacosjmg</a></li>
                    <li> <img src ="images/2.png" width="50" height="50"> <a href="https://www.instagram.com/?hl=es-la"> @farmacosjmg</a></li>
                </ul>
            </div>

            <div class="col-md-6 col-lg-3">
                <div class="block-5 mb-5">
                    <h3>Dirección</h3>
                    <ul class="list-unstyled">
                        <li class="address">Av. Bruselas, Santo Domingo, Ecuador</li>
                        <li class="phone"><a href="tel:// 097842351">0939257678</a></li>
                        <li class="email">farmacosjmg@gmail.com</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
   
    <div class="row pt-5 mt-5 text-center">
        <div class="col-md-12">
            <p>
                <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
                Copyright &copy;
                <script>document.write(new Date().getFullYear());</script> Todos los derechos reservados            
            </p>
        </div>
    </div>
</footer>
  <script src="js/jquery-3.3.1.min.js"></script>
  <script src="js/jquery-ui.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/main.js"></script>
