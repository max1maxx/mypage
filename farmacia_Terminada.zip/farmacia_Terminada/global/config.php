<?php
define("KEY","develoteca");
define("COD","AES-128-ECB");

define("SERVIDOR","localhost");
define("USUARIO","root");
define("PASSWORD","");
define("DB","farmacia");
?>
